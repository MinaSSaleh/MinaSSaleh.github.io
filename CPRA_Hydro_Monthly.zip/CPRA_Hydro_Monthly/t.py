import os
from os import listdir as ls

import re
import time


for f in [a for a in ls() if ".zip" in a]:
    if f.replace(".zip", "") + ".csv" not in ls():
        os.system("unzip {}".format(f))
        for a in ls():
            if re.match("^[A-Z0-9]{12}", a):
                os.system("mv {} {}".format(a, f.replace(".zip", ".csv")))


